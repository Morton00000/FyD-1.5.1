The retextured wood for forestry, natura, and Biomes O Plenty.
Also the properties files for all the blocks need to have the proper item IDs and metadata.
Also the smoldering grass top for Biomes O Plenty needs to be retextured by me so don't mind the unfinshed texture.
Also the quick sand for Biomes O Plenty needs to be textured by me also.
